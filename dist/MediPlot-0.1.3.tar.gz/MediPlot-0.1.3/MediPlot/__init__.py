from MediPlot.BodyMap import BodyMap

